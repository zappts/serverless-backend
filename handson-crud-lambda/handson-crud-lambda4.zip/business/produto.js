/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
const ProdutoRepository = require('../repository/produtoRepository');
const produtoRepository = new ProdutoRepository();
const ProdutoSchema = require('../schema/produtoSchema');
const produtoSchema = new ProdutoSchema();

class Produto {
  async create(id, nome, quantidade) {
    try {
        await produtoSchema.validade(id, nome, quantidade);
        await produtoRepository.createProduto(id, nome, quantidade);
    } catch(error) {
        throw error;
    }
  }
}

module.exports = Produto;