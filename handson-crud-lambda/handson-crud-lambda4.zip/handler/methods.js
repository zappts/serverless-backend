// POST /produto
// evento => request HTTP

// POSTMAN
/* 
{
    "id": number,
    "nome": string,
    "quantidade": number
}  =>>> string 

*/
const Produto = require('../business/produto');
const produto = new Produto();

module.exports.createProduto = async (event) => {
    const requestBody = JSON.parse(event.body);
    await produto.create(requestBody.id, requestBody.nome,
                                requestBody.quantidade);
    const response = {
        statusCode: 201,
        body: JSON.stringify({ message: 'Produto criado com sucesso!' }),
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'DELETE,GET,HEAD,OPTIONS,PATCH,POST,PUT',
            'Access-Control-Allow-Credentials': true,
        },
    }
    return response;
}