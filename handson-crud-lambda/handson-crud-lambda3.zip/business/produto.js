/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
const ProdutoRepository = require('../repository/produtoRepository');
const produtoRepository = new ProdutoRepository();

class Produto {
  async create(id, nome, quantidade) {
    await produtoRepository.createProduto(id, nome, quantidade);
  }
}

module.exports = Produto;